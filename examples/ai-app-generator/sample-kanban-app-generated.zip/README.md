# Task Manager Pro

A modern, feature-rich Kanban-style task management application built with React and TypeScript.

![Task Manager Pro](https://img.shields.io/badge/React-18.2-blue) ![TypeScript](https://img.shields.io/badge/TypeScript-5.3-blue) ![Tailwind](https://img.shields.io/badge/Tailwind-3.4-06B6D4) ![Vite](https://img.shields.io/badge/Vite-5.0-646CFF)

![kanban-board](./kanban.gif)

## ✨ Features

- **Kanban Board** - Drag and drop tasks between columns
- **Task Management** - Create, edit, and organize tasks
- **Priority Levels** - High, Medium, Low priority indicators
- **Due Dates** - Track deadlines with date assignments
- **Team Assignment** - Assign tasks to team members
- **Tags & Labels** - Categorize tasks with custom tags
- **Search & Filter** - Find tasks quickly
- **Responsive Sidebar** - Collapsible navigation
- **Real-time Updates** - Live task count and statistics

## 🛠 Tech Stack

| Category | Technology |
|----------|------------|
| **Frontend** | React 18 with TypeScript |
| **Styling** | Tailwind CSS + Inline Styles |
| **State Management** | Zustand |
| **Drag & Drop** | React DnD |
| **Icons** | Lucide React |
| **Build Tool** | Vite |
| **Testing** | Vitest + React Testing Library |

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

```bash
# Clone the repository
git clone <repository-url>
cd task-manager-pro

# Install dependencies
npm install

# Start development server
npm run dev
```

The app will be available at `http://localhost:3000`

### Available Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server |
| `npm run build` | Build for production |
| `npm run preview` | Preview production build |
| `npm run test` | Run tests |
| `npm run lint` | Lint code |

## 📁 Project Structure

```
task-manager-pro/
├── components/           # React components
│   ├── KanbanBoard.tsx   # Main board component
│   ├── KanbanColumn.tsx  # Column component with drop zone
│   ├── TaskCard.tsx      # Draggable task card
│   ├── Header.tsx        # App header
│   ├── Sidebar/          # Navigation sidebar
│   │   └── Sidebar.tsx
│   ├── TaskDetailsModal.tsx
│   ├── TaskForm.tsx
│   └── ui/               # Reusable UI components
│       ├── Button.tsx
│       ├── Avatar.tsx
│       └── Badge.tsx
├── hooks/                # Custom React hooks
│   ├── useKanbanDragDrop.ts
│   ├── useTaskActions.ts
│   └── useSidebar.ts
├── stores/               # Zustand stores
│   └── sidebarStore.ts
├── types/                # TypeScript definitions
│   ├── kanban.ts
│   └── task.ts
├── lib/                  # Utility libraries
│   └── utils.ts
├── src/
│   ├── App.tsx           # Main app component
│   ├── main.tsx          # Entry point
│   └── index.css         # Global styles
├── __tests__/            # Test files
├── stories/              # Storybook stories
└── public/               # Static assets
```

## 🧩 Components

### KanbanBoard
The main board component that orchestrates columns and drag-and-drop functionality.

```tsx
<KanbanBoard
  columns={columns}
  onMoveTask={handleMoveTask}
  onAddTask={handleAddTask}
  searchQuery={searchQuery}
  onSearchChange={setSearchQuery}
/>
```

### KanbanColumn
Represents a single column with drop zone support.

### TaskCard
Draggable task card displaying title, description, tags, priority, assignee, and due date.

### Sidebar
Collapsible navigation sidebar with:
- Main navigation (Dashboard, Tasks, Calendar, Analytics)
- Quick access (Starred, Recent, Archived)
- User profile section

## 🐳 Docker Deployment

```bash
# Build image
docker build -t task-manager-pro .

# Run container
docker run -p 80:80 task-manager-pro
```

## 📦 Dependencies

### Production
- `react` & `react-dom` - UI library
- `lucide-react` - Icons
- `react-dnd` & `react-dnd-html5-backend` - Drag and drop
- `zustand` - State management
- `clsx` & `tailwind-merge` - Class utilities

### Development
- `typescript` - Type checking
- `vite` - Build tool
- `tailwindcss` - Styling
- `vitest` - Testing
- `eslint` - Linting

## 🎨 Styling

The app uses a combination of:
- **Tailwind CSS** for utility classes
- **Inline styles** for component-specific styling (ensures styles always apply)
- **CSS variables** for theming

## 📄 License

MIT License

---

Built with ❤️ using React and TypeScript
