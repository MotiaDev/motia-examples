/**
 * Task Manager Pro
 * A modern task management application with Kanban board
 */

import React, { useState, useCallback } from 'react';
import './index.css';
import { KanbanBoard } from '../components/KanbanBoard';
import { Sidebar } from '../components/Sidebar';
import type { Column, Task } from '../types/kanban';

// Sample data for the Kanban board
const initialColumns: Column[] = [
  {
    id: 'backlog',
    title: 'Backlog',
    color: '#6366f1',
    order: 0,
    tasks: [
      {
        id: 'task-1',
        title: 'Research competitor features',
        description: 'Analyze top 5 competitors and document their key features',
        priority: 'medium',
        assignee: 'Sarah Chen',
        tags: ['research', 'planning'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'task-2',
        title: 'Design system documentation',
        description: 'Create comprehensive docs for the design system components',
        priority: 'low',
        tags: ['documentation', 'design'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
  },
  {
    id: 'todo',
    title: 'To Do',
    color: '#f59e0b',
    order: 1,
    tasks: [
      {
        id: 'task-3',
        title: 'Implement user authentication',
        description: 'Add OAuth2 login with Google and GitHub providers',
        priority: 'high',
        assignee: 'Alex Kim',
        dueDate: '2025-12-15',
        tags: ['feature', 'security'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'task-4',
        title: 'Setup CI/CD pipeline',
        description: 'Configure GitHub Actions for automated testing and deployment',
        priority: 'high',
        assignee: 'Mike Johnson',
        tags: ['devops', 'automation'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'task-5',
        title: 'Mobile responsive design',
        description: 'Ensure all components work well on mobile devices',
        priority: 'medium',
        tags: ['design', 'mobile'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
  },
  {
    id: 'in-progress',
    title: 'In Progress',
    color: '#3b82f6',
    order: 2,
    limit: 5,
    tasks: [
      {
        id: 'task-6',
        title: 'Build dashboard analytics',
        description: 'Create charts and metrics visualization for the dashboard',
        priority: 'high',
        assignee: 'Sarah Chen',
        dueDate: '2025-12-10',
        tags: ['feature', 'analytics'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'task-7',
        title: 'API integration tests',
        description: 'Write comprehensive test suite for all API endpoints',
        priority: 'medium',
        assignee: 'Alex Kim',
        tags: ['testing', 'api'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
  },
  {
    id: 'review',
    title: 'In Review',
    color: '#8b5cf6',
    order: 3,
    tasks: [
      {
        id: 'task-8',
        title: 'Landing page redesign',
        description: 'Complete overhaul of the marketing landing page',
        priority: 'medium',
        assignee: 'Emma Wilson',
        tags: ['design', 'marketing'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
  },
  {
    id: 'done',
    title: 'Done',
    color: '#22c55e',
    order: 4,
    tasks: [
      {
        id: 'task-9',
        title: 'Project setup and configuration',
        description: 'Initialize project with Vite, React, TypeScript, and Tailwind',
        priority: 'high',
        assignee: 'Mike Johnson',
        tags: ['setup', 'config'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'task-10',
        title: 'Component library setup',
        description: 'Create base UI components with consistent styling',
        priority: 'medium',
        assignee: 'Emma Wilson',
        tags: ['components', 'ui'],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
  },
];

function App() {
  const [columns, setColumns] = useState<Column[]>(initialColumns);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showNewTaskModal, setShowNewTaskModal] = useState(false);
  const [currentView, setCurrentView] = useState('tasks');

  // Calculate total tasks
  const totalTasks = columns.reduce((sum, col) => sum + col.tasks.length, 0);

  // Handle moving tasks between columns
  const handleMoveTask = useCallback((
    taskId: string,
    sourceColumnId: string,
    targetColumnId: string,
    targetIndex: number
  ) => {
    setColumns(prevColumns => {
      const newColumns = prevColumns.map(col => ({
        ...col,
        tasks: [...col.tasks]
      }));
      
      const sourceColumn = newColumns.find(col => col.id === sourceColumnId);
      const targetColumn = newColumns.find(col => col.id === targetColumnId);
      
      if (!sourceColumn || !targetColumn) return prevColumns;
      
      const taskIndex = sourceColumn.tasks.findIndex(task => task.id === taskId);
      if (taskIndex === -1) return prevColumns;
      
      const [task] = sourceColumn.tasks.splice(taskIndex, 1);
      
      targetColumn.tasks.splice(targetIndex, 0, {
        ...task,
        updatedAt: new Date().toISOString(),
      });
      
      return newColumns;
    });
  }, []);

  // Handle task click
  const handleTaskClick = useCallback((task: Task) => {
    setSelectedTask(task);
  }, []);

  // Handle adding a new task to a column
  const handleAddTask = useCallback((columnId: string) => {
    const newTask: Task = {
      id: `task-${Date.now()}`,
      title: 'New Task',
      description: 'Click to edit this task',
      priority: 'medium',
      tags: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setColumns(prevColumns => 
      prevColumns.map(column =>
        column.id === columnId
          ? { ...column, tasks: [...column.tasks, newTask] }
          : column
      )
    );
  }, []);

  // Handle "New Task" button from sidebar - adds to first column
  const handleNewTaskFromSidebar = useCallback(() => {
    const newTask: Task = {
      id: `task-${Date.now()}`,
      title: 'New Task',
      description: 'Click to edit this task',
      priority: 'medium',
      tags: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setColumns(prevColumns => {
      if (prevColumns.length === 0) return prevColumns;
      return prevColumns.map((column, index) =>
        index === 0
          ? { ...column, tasks: [newTask, ...column.tasks] }
          : column
      );
    });
  }, []);

  // Handle adding a new column
  const handleAddColumn = useCallback(() => {
    const newColumn: Column = {
      id: `column-${Date.now()}`,
      title: 'New Column',
      color: '#64748b',
      order: columns.length,
      tasks: [],
    };

    setColumns(prevColumns => [...prevColumns, newColumn]);
  }, [columns.length]);

  // Handle navigation change
  const handleNavigationChange = useCallback((viewId: string) => {
    setCurrentView(viewId);
  }, []);

  return (
    <div style={{ display: 'flex', height: '100vh', backgroundColor: '#f3f4f6' }}>
      {/* Sidebar */}
      <Sidebar 
        onNewTask={handleNewTaskFromSidebar}
        onNavigate={handleNavigationChange}
        currentView={currentView}
        taskCount={totalTasks}
      />
      
      {/* Main Content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {currentView === 'tasks' || currentView === 'dashboard' ? (
          <KanbanBoard
            columns={columns}
            onMoveTask={handleMoveTask}
            onTaskClick={handleTaskClick}
            onAddTask={handleAddTask}
            onAddColumn={handleAddColumn}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
          />
        ) : (
          <div style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: '#f9fafb',
            gap: '16px'
          }}>
            <div style={{
              width: '80px',
              height: '80px',
              backgroundColor: '#e5e7eb',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <span style={{ fontSize: '32px' }}>
                {currentView === 'calendar' && '📅'}
                {currentView === 'analytics' && '📊'}
                {currentView === 'starred' && '⭐'}
                {currentView === 'recent' && '🕐'}
                {currentView === 'archived' && '📁'}
              </span>
            </div>
            <h2 style={{ fontSize: '24px', fontWeight: 600, color: '#111827', margin: 0 }}>
              {currentView.charAt(0).toUpperCase() + currentView.slice(1)}
            </h2>
            <p style={{ fontSize: '14px', color: '#6b7280', margin: 0 }}>
              This feature is coming soon!
            </p>
            <button
              onClick={() => handleNavigationChange('tasks')}
              style={{
                marginTop: '16px',
                padding: '10px 20px',
                backgroundColor: '#3b82f6',
                color: 'white',
                border: 'none',
                borderRadius: '8px',
                fontSize: '14px',
                fontWeight: 500,
                cursor: 'pointer'
              }}
            >
              Go to Tasks
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
