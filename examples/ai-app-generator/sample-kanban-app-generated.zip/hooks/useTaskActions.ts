import { useCallback } from 'react';
import { Task, TaskStatus } from '../types/task';

/**
 * Custom hook for task-related actions
 */
export const useTaskActions = () => {
  /**
   * Handles task status change
   */
  const handleStatusChange = useCallback((taskId: string, newStatus: TaskStatus) => {
    // This would typically interact with your Zustand store
    console.log(`Changing task ${taskId} status to ${newStatus}`);
    // Example: useTaskStore.getState().updateTaskStatus(taskId, newStatus);
  }, []);

  /**
   * Handles task editing
   */
  const handleEdit = useCallback((task: Task) => {
    console.log('Editing task:', task);
    // This would typically open an edit modal or navigate to edit page
  }, []);

  /**
   * Handles task deletion
   */
  const handleDelete = useCallback((taskId: string) => {
    console.log('Deleting task:', taskId);
    // This would typically show a confirmation dialog and delete the task
  }, []);

  /**
   * Handles task duplication
   */
  const handleDuplicate = useCallback((task: Task) => {
    console.log('Duplicating task:', task);
    // This would typically create a new task with similar properties
  }, []);

  return {
    handleStatusChange,
    handleEdit,
    handleDelete,
    handleDuplicate
  };
};