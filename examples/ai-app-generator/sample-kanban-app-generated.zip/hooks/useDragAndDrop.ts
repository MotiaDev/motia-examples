import { useCallback } from 'react';
import { useDrop, useDrag } from 'react-dnd';
import type { DragItem } from '../types/kanban';

/**
 * Custom hook for handling drag and drop functionality in Kanban columns
 */
export const useColumnDrop = (
  columnId: string,
  onMoveTask: (taskId: string, sourceColumnId: string, targetColumnId: string, targetIndex: number) => void
) => {
  const [{ isOver, canDrop }, drop] = useDrop({
    accept: 'task',
    drop: (item: DragItem, monitor) => {
      if (!monitor.didDrop()) {
        onMoveTask(item.id, item.columnId, columnId, 0);
      }
    },
    collect: (monitor) => ({
      isOver: monitor.isOver({ shallow: true }),
      canDrop: monitor.canDrop(),
    }),
  });

  return { isOver, canDrop, drop };
};

/**
 * Custom hook for task drag functionality
 */
export const useTaskDrag = (taskId: string, columnId: string, index: number) => {
  const [{ isDragging }, drag] = useDrag({
    type: 'task',
    item: { id: taskId, type: 'task', columnId, index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  return { isDragging, drag };
};