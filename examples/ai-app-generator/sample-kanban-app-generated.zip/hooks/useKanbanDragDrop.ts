import { useCallback } from 'react';
import { useDrop, useDrag } from 'react-dnd';
import type { DragItem, Task } from '../types/kanban';

interface UseKanbanDragDropProps {
  onMoveTask: (taskId: string, sourceColumnId: string, targetColumnId: string, targetIndex: number) => void;
}

/**
 * Custom hook for handling drag and drop functionality in the Kanban board
 */
export const useKanbanDragDrop = ({ onMoveTask }: UseKanbanDragDropProps) => {
  const createDropTarget = useCallback((columnId: string) => {
    const [{ isOver, canDrop }, drop] = useDrop<DragItem, void, { isOver: boolean; canDrop: boolean }>({
      accept: 'task',
      drop: (item, monitor) => {
        if (!monitor.didDrop()) {
          onMoveTask(item.id, item.columnId, columnId, 0);
        }
      },
      collect: (monitor) => ({
        isOver: monitor.isOver({ shallow: true }),
        canDrop: monitor.canDrop(),
      }),
    });

    return { drop, isOver, canDrop };
  }, [onMoveTask]);

  const createDragSource = useCallback((task: Task, columnId: string, index: number) => {
    const [{ isDragging }, drag] = useDrag<DragItem, void, { isDragging: boolean }>({
      type: 'task',
      item: { id: task.id, type: 'task', columnId, index },
      collect: (monitor) => ({
        isDragging: monitor.isDragging(),
      }),
    });

    return { drag, isDragging };
  }, []);

  return { createDropTarget, createDragSource };
};