import { useSidebarStore } from '@/stores/sidebarStore';

/**
 * Custom hook for sidebar functionality
 * Provides a clean interface for components to interact with sidebar state
 * 
 * @returns Sidebar state and actions
 */
export const useSidebar = () => {
  const {
    isCollapsed,
    activeItem,
    toggleCollapsed,
    setActiveItem,
    setCollapsed,
  } = useSidebarStore();

  /**
   * Navigate to a specific item and set it as active
   * @param itemId - The ID of the navigation item
   */
  const navigateToItem = (itemId: string) => {
    setActiveItem(itemId);
    // Here you could also handle actual navigation with Next.js router
    // const router = useRouter();
    // router.push(`/${itemId}`);
  };

  /**
   * Expand the sidebar if it's collapsed
   */
  const expandSidebar = () => {
    if (isCollapsed) {
      setCollapsed(false);
    }
  };

  /**
   * Collapse the sidebar if it's expanded
   */
  const collapseSidebar = () => {
    if (!isCollapsed) {
      setCollapsed(true);
    }
  };

  return {
    // State
    isCollapsed,
    activeItem,
    
    // Actions
    toggleCollapsed,
    setActiveItem,
    setCollapsed,
    navigateToItem,
    expandSidebar,
    collapseSidebar,
  };
};