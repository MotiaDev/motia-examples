import { useState, useEffect, useCallback } from 'react';
import { NotificationItem, UserProfile } from '../types/header';

/**
 * Custom hook for managing header state and functionality
 */
export const useHeader = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  /**
   * Mock user data - in a real app, this would come from auth context
   */
  const [user] = useState<UserProfile>({
    id: '1',
    name: 'John Doe',
    email: 'john.doe@company.com',
    role: 'Project Manager'
  });

  /**
   * Initialize notifications - in a real app, this would fetch from API
   */
  useEffect(() => {
    const mockNotifications: NotificationItem[] = [
      {
        id: '1',
        title: 'Task deadline approaching',
        message: 'Website redesign due in 2 hours',
        timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
        read: false,
        type: 'warning'
      },
      {
        id: '2',
        title: 'New project assigned',
        message: 'Mobile app development project',
        timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 hour ago
        read: false,
        type: 'info'
      },
      {
        id: '3',
        title: 'Team meeting reminder',
        message: 'Daily standup in 30 minutes',
        timestamp: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
        read: false,
        type: 'info'
      }
    ];

    setNotifications(mockNotifications);
    setUnreadCount(mockNotifications.filter(n => !n.read).length);
  }, []);

  /**
   * Toggle mobile menu
   */
  const toggleMenu = useCallback(() => {
    setIsMenuOpen(prev => !prev);
  }, []);

  /**
   * Toggle user dropdown menu
   */
  const toggleUserMenu = useCallback(() => {
    setIsUserMenuOpen(prev => !prev);
  }, []);

  /**
   * Toggle notifications dropdown
   */
  const toggleNotifications = useCallback(() => {
    setIsNotificationsOpen(prev => !prev);
  }, []);

  /**
   * Close all dropdowns
   */
  const closeAllDropdowns = useCallback(() => {
    setIsUserMenuOpen(false);
    setIsNotificationsOpen(false);
  }, []);

  /**
   * Handle search input change
   */
  const handleSearchChange = useCallback((query: string) => {
    setSearchQuery(query);
    // In a real app, you might debounce this and trigger search
  }, []);

  /**
   * Mark notification as read
   */
  const markNotificationAsRead = useCallback((notificationId: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === notificationId 
          ? { ...notification, read: true }
          : notification
      )
    );
    setUnreadCount(prev => Math.max(0, prev - 1));
  }, []);

  /**
   * Handle user menu actions
   */
  const handleUserMenuAction = useCallback((action: string) => {
    switch (action) {
      case 'profile':
        // Navigate to profile
        console.log('Navigate to profile');
        break;
      case 'preferences':
        // Navigate to preferences
        console.log('Navigate to preferences');
        break;
      case 'help':
        // Navigate to help
        console.log('Navigate to help');
        break;
      case 'signout':
        // Handle sign out
        console.log('Sign out user');
        break;
      default:
        break;
    }
    closeAllDropdowns();
  }, [closeAllDropdowns]);

  /**
   * Close mobile menu when screen size changes
   */
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768) { // md breakpoint
        setIsMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  /**
   * Close dropdowns when clicking outside
   */
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (!target.closest('[data-dropdown]')) {
        closeAllDropdowns();
      }
    };

    if (isUserMenuOpen || isNotificationsOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isUserMenuOpen, isNotificationsOpen, closeAllDropdowns]);

  return {
    // State
    isMenuOpen,
    isUserMenuOpen,
    isNotificationsOpen,
    searchQuery,
    notifications,
    unreadCount,
    user,
    
    // Actions
    toggleMenu,
    toggleUserMenu,
    toggleNotifications,
    closeAllDropdowns,
    handleSearchChange,
    markNotificationAsRead,
    handleUserMenuAction
  };
};