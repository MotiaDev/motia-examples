import { useState, useEffect } from 'react';
import { Task, TaskFormData } from '../types/task';

interface UseTaskFormProps {
  initialValues?: Task;
  onSubmit: (task: Task) => void;
}

interface FormErrors {
  title?: string;
  description?: string;
  dueDate?: string;
}

/**
 * Custom hook for managing task form state and validation
 */
export const useTaskForm = ({ initialValues, onSubmit }: UseTaskFormProps) => {
  const [formData, setFormData] = useState<TaskFormData>({
    title: '',
    description: '',
    priority: 'medium',
    status: 'todo',
    dueDate: '',
    tags: [],
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [tagInput, setTagInput] = useState('');

  // Initialize form with initial values if provided
  useEffect(() => {
    if (initialValues) {
      setFormData({
        title: initialValues.title,
        description: initialValues.description,
        priority: initialValues.priority,
        status: initialValues.status,
        dueDate: initialValues.dueDate || '',
        tags: initialValues.tags,
      });
    }
  }, [initialValues]);

  /**
   * Validates form data and returns validation errors
   */
  const validateForm = (): FormErrors => {
    const newErrors: FormErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    } else if (formData.title.trim().length < 3) {
      newErrors.title = 'Title must be at least 3 characters long';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    } else if (formData.description.trim().length < 10) {
      newErrors.description = 'Description must be at least 10 characters long';
    }

    if (formData.dueDate) {
      const selectedDate = new Date(formData.dueDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (selectedDate < today) {
        newErrors.dueDate = 'Due date cannot be in the past';
      }
    }

    return newErrors;
  };

  /**
   * Updates a specific field in the form data
   */
  const updateField = <K extends keyof TaskFormData>(
    field: K,
    value: TaskFormData[K]
  ) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    
    // Clear error for this field when user starts typing
    if (errors[field as keyof FormErrors]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  /**
   * Adds a new tag to the task
   */
  const addTag = (tag: string) => {
    const trimmedTag = tag.trim().toLowerCase();
    if (trimmedTag && !formData.tags.includes(trimmedTag)) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, trimmedTag]
      }));
    }
    setTagInput('');
  };

  /**
   * Removes a tag from the task
   */
  const removeTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  /**
   * Handles form submission with validation
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setIsSubmitting(true);
    
    try {
      const now = new Date().toISOString();
      const taskData: Task = {
        id: initialValues?.id || crypto.randomUUID(),
        ...formData,
        createdAt: initialValues?.createdAt || now,
        updatedAt: now,
      };

      await onSubmit(taskData);
    } catch (error) {
      console.error('Error submitting task:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  /**
   * Resets the form to initial state
   */
  const resetForm = () => {
    if (initialValues) {
      setFormData({
        title: initialValues.title,
        description: initialValues.description,
        priority: initialValues.priority,
        status: initialValues.status,
        dueDate: initialValues.dueDate || '',
        tags: initialValues.tags,
      });
    } else {
      setFormData({
        title: '',
        description: '',
        priority: 'medium',
        status: 'todo',
        dueDate: '',
        tags: [],
      });
    }
    setErrors({});
    setTagInput('');
  };

  return {
    formData,
    errors,
    isSubmitting,
    tagInput,
    setTagInput,
    updateField,
    addTag,
    removeTag,
    handleSubmit,
    resetForm,
  };
};