/**
 * Type definitions for Header component
 */

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  type: 'info' | 'warning' | 'success' | 'error';
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: string;
}

export interface NavigationItem {
  label: string;
  href: string;
  icon?: React.ComponentType<{ className?: string }>;
  active?: boolean;
}

export interface HeaderProps {
  user?: UserProfile;
  notifications?: NotificationItem[];
  navigationItems?: NavigationItem[];
  onSearch?: (query: string) => void;
  onNotificationClick?: (notification: NotificationItem) => void;
  onUserMenuAction?: (action: string) => void;
}