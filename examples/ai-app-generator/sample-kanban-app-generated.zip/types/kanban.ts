export interface Task {
  id: string;
  title: string;
  description?: string;
  priority: 'low' | 'medium' | 'high';
  assignee?: string;
  dueDate?: string;
  tags?: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Column {
  id: string;
  title: string;
  color: string;
  tasks: Task[];
  order: number;
  limit?: number;
}

export interface DragItem {
  id: string;
  type: 'task';
  columnId: string;
  index: number;
}