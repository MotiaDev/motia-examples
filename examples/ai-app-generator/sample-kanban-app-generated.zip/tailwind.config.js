/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
    "./hooks/**/*.{js,ts,jsx,tsx}",
    "./stores/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#3b82f6',
        secondary: '#60a5fa',
        accent: '#e5e7eb',
      },
      fontFamily: {
        heading: ['Inter, sans-serif', 'sans-serif'],
        body: ['Inter, sans-serif', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
