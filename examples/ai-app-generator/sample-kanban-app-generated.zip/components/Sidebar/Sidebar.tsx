'use client';

import React, { useState } from 'react';
import { 
  Home, 
  CheckSquare, 
  Calendar, 
  BarChart3, 
  Settings, 
  Plus,
  ChevronLeft,
  ChevronRight,
  User,
  Bell,
  Archive,
  Star,
  Clock
} from 'lucide-react';
import { useSidebarStore } from '../../stores/sidebarStore';

interface SidebarProps {
  onNewTask?: () => void;
  onNavigate?: (viewId: string) => void;
  currentView?: string;
  taskCount?: number;
}

interface NavigationItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ style?: React.CSSProperties }>;
  badge?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  onNewTask,
  onNavigate,
  currentView = 'tasks',
  taskCount = 0
}) => {
  const { isCollapsed, toggleCollapsed } = useSidebarStore();
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  const navigationItems: NavigationItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'tasks', label: 'Tasks', icon: CheckSquare, badge: taskCount },
    { id: 'calendar', label: 'Calendar', icon: Calendar },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 }
  ];

  const secondaryItems: NavigationItem[] = [
    { id: 'starred', label: 'Starred', icon: Star },
    { id: 'recent', label: 'Recent', icon: Clock },
    { id: 'archived', label: 'Archived', icon: Archive }
  ];

  const handleItemClick = (itemId: string) => {
    onNavigate?.(itemId);
  };

  const handleNewTaskClick = () => {
    onNewTask?.();
  };

  const renderNavigationItem = (item: NavigationItem) => {
    const isHovered = hoveredItem === item.id;
    const isActive = currentView === item.id;
    const IconComponent = item.icon;

    return (
      <li key={item.id} style={{ listStyle: 'none' }}>
        <button
          onClick={() => handleItemClick(item.id)}
          onMouseEnter={() => setHoveredItem(item.id)}
          onMouseLeave={() => setHoveredItem(null)}
          style={{
            width: '100%',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            padding: isCollapsed ? '10px' : '10px 12px',
            borderRadius: '8px',
            border: 'none',
            backgroundColor: isActive ? '#3b82f6' : isHovered ? '#eff6ff' : 'transparent',
            color: isActive ? 'white' : isHovered ? '#3b82f6' : '#374151',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: 500,
            transition: 'all 0.2s ease',
            justifyContent: isCollapsed ? 'center' : 'flex-start',
            position: 'relative'
          }}
          aria-label={item.label}
          aria-current={isActive ? 'page' : undefined}
        >
          <IconComponent style={{ 
            width: '20px', 
            height: '20px',
            flexShrink: 0,
            color: isActive ? 'white' : isHovered ? '#3b82f6' : '#6b7280'
          }} />
          
          {!isCollapsed && (
            <>
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {item.label}
              </span>
              {item.badge !== undefined && item.badge > 0 && (
                <span style={{
                  marginLeft: 'auto',
                  padding: '2px 8px',
                  fontSize: '12px',
                  fontWeight: 600,
                  borderRadius: '12px',
                  backgroundColor: isActive ? 'rgba(255,255,255,0.2)' : '#dbeafe',
                  color: isActive ? 'white' : '#3b82f6'
                }}>
                  {item.badge}
                </span>
              )}
            </>
          )}

          {isCollapsed && isHovered && (
            <div style={{
              position: 'absolute',
              left: '100%',
              marginLeft: '8px',
              padding: '4px 8px',
              backgroundColor: '#1f2937',
              color: 'white',
              fontSize: '12px',
              borderRadius: '4px',
              whiteSpace: 'nowrap',
              zIndex: 50,
              boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
            }}>
              {item.label}
              {item.badge !== undefined && item.badge > 0 && (
                <span style={{
                  marginLeft: '8px',
                  padding: '2px 6px',
                  backgroundColor: '#3b82f6',
                  borderRadius: '12px'
                }}>
                  {item.badge}
                </span>
              )}
            </div>
          )}
        </button>
      </li>
    );
  };

  return (
    <aside 
      style={{
        backgroundColor: 'white',
        borderRight: '1px solid #e5e7eb',
        height: '100vh',
        display: 'flex',
        flexDirection: 'column',
        width: isCollapsed ? '64px' : '256px',
        transition: 'width 0.3s ease',
        flexShrink: 0
      }}
      aria-label="Main navigation"
    >
      {/* Header */}
      <div style={{ 
        padding: '16px', 
        borderBottom: '1px solid #e5e7eb',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        {!isCollapsed && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <div style={{
              width: '32px',
              height: '32px',
              backgroundColor: '#3b82f6',
              borderRadius: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <CheckSquare style={{ width: '20px', height: '20px', color: 'white' }} />
            </div>
            <div>
              <h1 style={{ fontSize: '16px', fontWeight: 700, color: '#111827', margin: 0 }}>TaskPro</h1>
              <p style={{ fontSize: '11px', color: '#9ca3af', margin: 0 }}>Productivity Suite</p>
            </div>
          </div>
        )}
        
        <button
          onClick={toggleCollapsed}
          style={{
            padding: '6px',
            borderRadius: '8px',
            border: 'none',
            backgroundColor: 'transparent',
            color: '#6b7280',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: isCollapsed ? 'auto' : 0
          }}
          aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isCollapsed ? (
            <ChevronRight style={{ width: '16px', height: '16px' }} />
          ) : (
            <ChevronLeft style={{ width: '16px', height: '16px' }} />
          )}
        </button>
      </div>

      {/* New Task Button */}
      <div style={{ padding: isCollapsed ? '8px' : '16px', borderBottom: '1px solid #e5e7eb' }}>
        <button 
          onClick={handleNewTaskClick}
          style={{
            width: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            padding: isCollapsed ? '10px' : '10px 12px',
            backgroundColor: '#3b82f6',
            color: 'white',
            borderRadius: '8px',
            border: 'none',
            fontSize: '14px',
            fontWeight: 500,
            cursor: 'pointer',
            transition: 'background-color 0.2s ease'
          }}
          onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#2563eb'}
          onMouseLeave={(e) => e.currentTarget.style.backgroundColor = '#3b82f6'}
        >
          <Plus style={{ width: '16px', height: '16px' }} />
          {!isCollapsed && <span>New Task</span>}
        </button>
      </div>

      {/* Navigation */}
      <nav style={{ flex: 1, padding: '16px', overflowY: 'auto' }}>
        <div style={{ marginBottom: '24px' }}>
          {!isCollapsed && (
            <h2 style={{
              fontSize: '11px',
              fontWeight: 600,
              color: '#9ca3af',
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              marginBottom: '12px',
              paddingLeft: '12px'
            }}>
              Main
            </h2>
          )}
          <ul style={{ margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: '4px' }}>
            {navigationItems.map(renderNavigationItem)}
          </ul>
        </div>

        <div>
          {!isCollapsed && (
            <h2 style={{
              fontSize: '11px',
              fontWeight: 600,
              color: '#9ca3af',
              textTransform: 'uppercase',
              letterSpacing: '0.05em',
              marginBottom: '12px',
              paddingLeft: '12px'
            }}>
              Quick Access
            </h2>
          )}
          <ul style={{ margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: '4px' }}>
            {secondaryItems.map(renderNavigationItem)}
          </ul>
        </div>
      </nav>

      {/* User Profile */}
      <div style={{ padding: '16px', borderTop: '1px solid #e5e7eb' }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          padding: '8px',
          borderRadius: '8px',
          cursor: 'pointer',
          justifyContent: isCollapsed ? 'center' : 'flex-start'
        }}>
          <div style={{
            width: '32px',
            height: '32px',
            backgroundColor: '#dbeafe',
            borderRadius: '50%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0
          }}>
            <User style={{ width: '16px', height: '16px', color: '#3b82f6' }} />
          </div>
          
          {!isCollapsed && (
            <>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ fontSize: '14px', fontWeight: 500, color: '#111827', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  John Doe
                </p>
                <p style={{ fontSize: '12px', color: '#9ca3af', margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  john@example.com
                </p>
              </div>
              <button style={{
                padding: '4px',
                borderRadius: '4px',
                border: 'none',
                backgroundColor: 'transparent',
                color: '#9ca3af',
                cursor: 'pointer'
              }}>
                <Settings style={{ width: '16px', height: '16px' }} />
              </button>
            </>
          )}
        </div>
      </div>

      {isCollapsed && (
        <div style={{ padding: '8px', borderTop: '1px solid #e5e7eb' }}>
          <button style={{
            width: '100%',
            padding: '8px',
            borderRadius: '8px',
            border: 'none',
            backgroundColor: 'transparent',
            cursor: 'pointer',
            position: 'relative',
            display: 'flex',
            justifyContent: 'center'
          }}>
            <Bell style={{ width: '20px', height: '20px', color: '#9ca3af' }} />
            <span style={{
              position: 'absolute',
              top: '4px',
              right: '12px',
              width: '8px',
              height: '8px',
              backgroundColor: '#ef4444',
              borderRadius: '50%'
            }}></span>
          </button>
        </div>
      )}
    </aside>
  );
};

export default Sidebar;
