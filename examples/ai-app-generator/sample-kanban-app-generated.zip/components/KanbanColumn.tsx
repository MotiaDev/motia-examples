import React from 'react';
import { useDrop } from 'react-dnd';
import { Plus, MoreVertical } from 'lucide-react';
import { TaskCard } from './TaskCard';
import type { Column, Task, DragItem } from '../types/kanban';

interface KanbanColumnProps {
  column: Column;
  onTaskClick?: (task: Task) => void;
  onAddTask?: (columnId: string) => void;
  onColumnMenuClick?: (columnId: string) => void;
  onMoveTask?: (taskId: string, sourceColumnId: string, targetColumnId: string, targetIndex: number) => void;
}

/**
 * Kanban column component that displays tasks and handles drag and drop
 */
export const KanbanColumn: React.FC<KanbanColumnProps> = ({
  column,
  onTaskClick,
  onAddTask,
  onColumnMenuClick,
  onMoveTask,
}) => {
  const [{ isOver, canDrop }, drop] = useDrop<DragItem, void, { isOver: boolean; canDrop: boolean }>({
    accept: 'task',
    drop: (item, monitor) => {
      if (!monitor.didDrop()) {
        onMoveTask?.(item.id, item.columnId, column.id, column.tasks.length);
      }
    },
    collect: (monitor) => ({
      isOver: monitor.isOver({ shallow: true }),
      canDrop: monitor.canDrop(),
    }),
  });

  const isAtLimit = column.limit && column.tasks.length >= column.limit;

  return (
    <div
      ref={drop}
      style={{
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: isOver && canDrop ? '#eff6ff' : '#f9fafb',
        borderRadius: '12px',
        border: `2px solid ${isOver && canDrop ? '#3b82f6' : isOver && !canDrop ? '#ef4444' : '#e5e7eb'}`,
        minHeight: '600px',
        width: '320px',
        flexShrink: 0,
        transition: 'all 0.2s ease',
        overflow: 'hidden'
      }}
      role="region"
      aria-label={`${column.title} column`}
    >
      {/* Column Header */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '16px',
        borderBottom: '1px solid #e5e7eb',
        backgroundColor: 'white'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          {/* Column Color Indicator */}
          <div
            style={{
              width: '12px',
              height: '12px',
              borderRadius: '50%',
              backgroundColor: column.color
            }}
            aria-hidden="true"
          />
          
          {/* Column Title and Count */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <h2 style={{ fontWeight: 600, color: '#111827', fontSize: '14px', margin: 0 }}>
              {column.title}
            </h2>
            <span style={{
              backgroundColor: '#f3f4f6',
              color: '#6b7280',
              fontSize: '12px',
              padding: '2px 8px',
              borderRadius: '12px',
              fontWeight: 500
            }}>
              {column.tasks.length}
              {column.limit && `/${column.limit}`}
            </span>
          </div>
        </div>

        {/* Column Actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <button
            onClick={() => onAddTask?.(column.id)}
            disabled={isAtLimit}
            style={{
              padding: '6px',
              borderRadius: '6px',
              border: 'none',
              backgroundColor: 'transparent',
              color: isAtLimit ? '#d1d5db' : '#6b7280',
              cursor: isAtLimit ? 'not-allowed' : 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.2s ease'
            }}
            title={isAtLimit ? 'Column limit reached' : 'Add new task'}
            aria-label={`Add task to ${column.title}`}
          >
            <Plus style={{ width: '16px', height: '16px' }} />
          </button>
          
          <button
            onClick={() => onColumnMenuClick?.(column.id)}
            style={{
              padding: '6px',
              borderRadius: '6px',
              border: 'none',
              backgroundColor: 'transparent',
              color: '#6b7280',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              transition: 'all 0.2s ease'
            }}
            title="Column options"
            aria-label={`Options for ${column.title} column`}
          >
            <MoreVertical style={{ width: '16px', height: '16px' }} />
          </button>
        </div>
      </div>

      {/* Column Limit Warning */}
      {isAtLimit && (
        <div style={{
          margin: '12px 16px 0',
          padding: '8px 12px',
          backgroundColor: '#fef3c7',
          border: '1px solid #fde68a',
          borderRadius: '6px'
        }}>
          <p style={{ color: '#92400e', fontSize: '12px', fontWeight: 500, margin: 0 }}>
            Column limit reached ({column.limit} tasks)
          </p>
        </div>
      )}

      {/* Tasks Container */}
      <div style={{
        flex: 1,
        padding: '16px',
        display: 'flex',
        flexDirection: 'column',
        gap: '12px',
        overflowY: 'auto'
      }}>
        {column.tasks.length === 0 ? (
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '48px 0',
            color: '#9ca3af'
          }}>
            <div style={{
              width: '48px',
              height: '48px',
              backgroundColor: '#e5e7eb',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: '12px'
            }}>
              <Plus style={{ width: '24px', height: '24px' }} />
            </div>
            <p style={{ fontSize: '14px', fontWeight: 500, marginBottom: '4px' }}>No tasks yet</p>
            <p style={{ fontSize: '12px', textAlign: 'center' }}>
              Drag tasks here or click + to add
            </p>
          </div>
        ) : (
          column.tasks.map((task, index) => (
            <TaskCard
              key={task.id}
              task={task}
              columnId={column.id}
              index={index}
              onClick={() => onTaskClick?.(task)}
            />
          ))
        )}
      </div>

      {/* Drop Zone Indicator */}
      {isOver && canDrop && (
        <div style={{
          margin: '0 16px 16px',
          padding: '12px',
          border: '2px dashed #3b82f6',
          borderRadius: '8px',
          backgroundColor: '#eff6ff'
        }}>
          <p style={{ color: '#2563eb', fontSize: '14px', fontWeight: 500, textAlign: 'center', margin: 0 }}>
            Drop task here
          </p>
        </div>
      )}
    </div>
  );
};
