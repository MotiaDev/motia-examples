import React from 'react';
import { cn } from '../../utils/cn';

interface AvatarProps {
  src?: string;
  alt?: string;
  fallback: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

/**
 * Avatar component for displaying user profile pictures or initials
 */
export const Avatar: React.FC<AvatarProps> = ({ 
  src, 
  alt, 
  fallback, 
  size = 'md', 
  className 
}) => {
  const sizeClasses = {
    sm: 'h-6 w-6 text-xs',
    md: 'h-8 w-8 text-sm',
    lg: 'h-10 w-10 text-base'
  };

  const baseClasses = 'inline-flex items-center justify-center rounded-full bg-gray-100 font-medium text-gray-600 ring-2 ring-white';

  if (src) {
    return (
      <img
        src={src}
        alt={alt || 'Avatar'}
        className={cn(baseClasses, sizeClasses[size], 'object-cover', className)}
      />
    );
  }

  return (
    <div className={cn(baseClasses, sizeClasses[size], className)}>
      {fallback}
    </div>
  );
};