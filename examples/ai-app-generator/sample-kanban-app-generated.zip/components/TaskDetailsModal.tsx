import React from 'react';
import { Task } from '../types/task';
import { useTaskDetails } from '../hooks/useTaskDetails';
import {
  X,
  Calendar,
  Clock,
  User,
  Tag,
  CheckCircle2,
  Circle,
  Paperclip,
  MessageSquare,
  BarChart3,
  Flag,
} from 'lucide-react';

interface TaskDetailsModalProps {
  /** Task object containing all task information */
  task: Task;
  /** Callback function to close the modal */
  onClose: () => void;
}

/**
 * TaskDetailsModal component displays comprehensive task information in a modal overlay
 * Features include task metadata, progress tracking, attachments, and comments
 */
export const TaskDetailsModal: React.FC<TaskDetailsModalProps> = ({
  task,
  onClose,
}) => {
  const {
    isClosing,
    handleClose,
    formatDate,
    getPriorityColor,
    getStatusColor,
    formatFileSize,
  } = useTaskDetails(task, onClose);

  const completedSubtasks = task.subtasks?.filter(subtask => subtask.completed).length || 0;
  const totalSubtasks = task.subtasks?.length || 0;
  const progressPercentage = totalSubtasks > 0 ? (completedSubtasks / totalSubtasks) * 100 : 0;

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50 transition-opacity duration-200 ${
        isClosing ? 'opacity-0' : 'opacity-100'
      }`}
      onClick={handleClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="task-details-title"
    >
      <div
        className={`relative w-full max-w-4xl max-h-[90vh] bg-white rounded-xl shadow-2xl overflow-hidden transition-all duration-200 ${
          isClosing ? 'scale-95 opacity-0' : 'scale-100 opacity-100'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200 bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex-1 min-w-0">
            <h1
              id="task-details-title"
              className="text-2xl font-bold text-gray-900 truncate font-inter"
            >
              {task.title}
            </h1>
            <div className="flex items-center gap-3 mt-2">
              <span
                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getStatusColor(
                  task.status
                )}`}
              >
                {task.status.replace('-', ' ').toUpperCase()}
              </span>
              <span
                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${getPriorityColor(
                  task.priority
                )}`}
              >
                <Flag className="w-3 h-3 mr-1" />
                {task.priority.toUpperCase()}
              </span>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
            aria-label="Close modal"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto max-h-[calc(90vh-120px)]">
          <div className="p-6 space-y-8">
            {/* Task Information Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left Column */}
              <div className="space-y-6">
                {/* Description */}
                {task.description && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3 font-inter">
                      Description
                    </h3>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                        {task.description}
                      </p>
                    </div>
                  </div>
                )}

                {/* Subtasks */}
                {task.subtasks && task.subtasks.length > 0 && (
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-lg font-semibold text-gray-900 font-inter">
                        Subtasks
                      </h3>
                      <span className="text-sm text-gray-500">
                        {completedSubtasks}/{totalSubtasks} completed
                      </span>
                    </div>
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${progressPercentage}%` }}
                        />
                      </div>
                      <div className="space-y-3">
                        {task.subtasks.map((subtask) => (
                          <div
                            key={subtask.id}
                            className="flex items-center gap-3 p-2 hover:bg-white rounded-md transition-colors duration-200"
                          >
                            {subtask.completed ? (
                              <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                            ) : (
                              <Circle className="w-5 h-5 text-gray-400 flex-shrink-0" />
                            )}
                            <span
                              className={`flex-1 ${
                                subtask.completed
                                  ? 'text-gray-500 line-through'
                                  : 'text-gray-900'
                              }`}
                            >
                              {subtask.title}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Tags */}
                {task.tags && task.tags.length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3 font-inter">
                      Tags
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {task.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800 border border-blue-200"
                        >
                          <Tag className="w-3 h-3 mr-1" />
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Right Column */}
              <div className="space-y-6">
                {/* Task Metadata */}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 font-inter">
                    Details
                  </h3>
                  <div className="bg-gray-50 rounded-lg p-4 space-y-4">
                    {task.assignee && (
                      <div className="flex items-center gap-3">
                        <User className="w-5 h-5 text-gray-400" />
                        <div>
                          <span className="text-sm text-gray-500">Assignee</span>
                          <p className="font-medium text-gray-900">{task.assignee}</p>
                        </div>
                      </div>
                    )}

                    {task.category && (
                      <div className="flex items-center gap-3">
                        <BarChart3 className="w-5 h-5 text-gray-400" />
                        <div>
                          <span className="text-sm text-gray-500">Category</span>
                          <p className="font-medium text-gray-900">{task.category}</p>
                        </div>
                      </div>
                    )}

                    {task.dueDate && (
                      <div className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-gray-400" />
                        <div>
                          <span className="text-sm text-gray-500">Due Date</span>
                          <p className="font-medium text-gray-900">
                            {formatDate(task.dueDate)}
                          </p>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center gap-3">
                      <Clock className="w-5 h-5 text-gray-400" />
                      <div>
                        <span className="text-sm text-gray-500">Created</span>
                        <p className="font-medium text-gray-900">
                          {formatDate(task.createdAt)}
                        </p>
                      </div>
                    </div>

                    {task.updatedAt !== task.createdAt && (
                      <div className="flex items-center gap-3">
                        <Clock className="w-5 h-5 text-gray-400" />
                        <div>
                          <span className="text-sm text-gray-500">Last Updated</span>
                          <p className="font-medium text-gray-900">
                            {formatDate(task.updatedAt)}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Time Tracking */}
                {(task.estimatedHours || task.actualHours) && (
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-3 font-inter">
                      Time Tracking
                    </h3>
                    <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                      {task.estimatedHours && (
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600">Estimated Hours</span>
                          <span className="font-medium text-gray-900">
                            {task.estimatedHours}h
                          </span>
                        </div>
                      )}
                      {task.actualHours && (
                        <div className="flex justify-between items-center">
                          <span className="text-gray-600">Actual Hours</span>
                          <span className="font-medium text-gray-900">
                            {task.actualHours}h
                          </span>
                        </div>
                      )}
                      {task.estimatedHours && task.actualHours && (
                        <div className="pt-2 border-t border-gray-200">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-600">Variance</span>
                            <span
                              className={`font-medium ${
                                task.actualHours > task.estimatedHours
                                  ? 'text-red-600'
                                  : 'text-green-600'
                              }`}
                            >
                              {task.actualHours > task.estimatedHours ? '+' : ''}
                              {task.actualHours - task.estimatedHours}h
                            </span>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Attachments */}
            {task.attachments && task.attachments.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3 font-inter">
                  Attachments
                </h3>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {task.attachments.map((attachment) => (
                      <div
                        key={attachment.id}
                        className="flex items-center gap-3 p-3 bg-white rounded-lg border border-gray-200 hover:border-blue-300 transition-colors duration-200"
                      >
                        <Paperclip className="w-5 h-5 text-gray-400 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-gray-900 truncate">
                            {attachment.name}
                          </p>
                          <p className="text-sm text-gray-500">
                            {formatFileSize(attachment.size)} • {formatDate(attachment.uploadedAt)}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Comments */}
            {task.comments && task.comments.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3 font-inter">
                  Comments
                </h3>
                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="space-y-4">
                    {task.comments.map((comment) => (
                      <div
                        key={comment.id}
                        className="flex gap-3 p-3 bg-white rounded-lg border border-gray-200"
                      >
                        <MessageSquare className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium text-gray-900">
                              {comment.author}
                            </span>
                            <span className="text-sm text-gray-500">
                              {formatDate(comment.createdAt)}
                            </span>
                          </div>
                          <p className="text-gray-700 leading-relaxed">
                            {comment.content}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-3 p-6 border-t border-gray-200 bg-gray-50">
          <button
            onClick={handleClose}
            className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 hover:border-gray-400 transition-colors duration-200 font-medium"
          >
            Close
          </button>
          <button className="px-4 py-2 text-white bg-blue-600 border border-blue-600 rounded-lg hover:bg-blue-700 hover:border-blue-700 transition-colors duration-200 font-medium">
            Edit Task
          </button>
        </div>
      </div>
    </div>
  );
};

export default TaskDetailsModal;