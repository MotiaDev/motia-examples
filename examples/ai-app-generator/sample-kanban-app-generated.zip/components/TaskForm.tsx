import React, { KeyboardEvent } from 'react';
import { Task } from '../types/task';
import { useTaskForm } from '../hooks/useTaskForm';
import {
  Calendar,
  Tag,
  AlertCircle,
  Plus,
  X,
  Save,
  RotateCcw,
  Clock,
  Flag,
  FileText,
  CheckCircle2,
} from 'lucide-react';

interface TaskFormProps {
  /** Callback function to handle form submission */
  onSubmit: (task: Task) => void;
  /** Initial values for the form (for editing existing tasks) */
  initialValues?: Task;
}

/**
 * TaskForm component for creating and editing tasks
 * Provides a comprehensive form with validation and modern UI
 */
export const TaskForm: React.FC<TaskFormProps> = ({
  onSubmit,
  initialValues,
}) => {
  const {
    formData,
    errors,
    isSubmitting,
    tagInput,
    setTagInput,
    updateField,
    addTag,
    removeTag,
    handleSubmit,
    resetForm,
  } = useTaskForm({ initialValues, onSubmit });

  const isEditing = Boolean(initialValues);

  /**
   * Handles adding tags when Enter key is pressed
   */
  const handleTagKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag(tagInput);
    }
  };

  /**
   * Gets the appropriate styling classes for priority levels
   */
  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-50 border-red-200 text-red-700';
      case 'medium':
        return 'bg-yellow-50 border-yellow-200 text-yellow-700';
      case 'low':
        return 'bg-green-50 border-green-200 text-green-700';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-700';
    }
  };

  /**
   * Gets the appropriate styling classes for status levels
   */
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-50 border-green-200 text-green-700';
      case 'in-progress':
        return 'bg-blue-50 border-blue-200 text-blue-700';
      case 'todo':
        return 'bg-gray-50 border-gray-200 text-gray-700';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-700';
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
        <h2 className="text-xl font-semibold text-white flex items-center gap-2">
          {isEditing ? (
            <>
              <FileText className="w-5 h-5" />
              Edit Task
            </>
          ) : (
            <>
              <Plus className="w-5 h-5" />
              Create New Task
            </>
          )}
        </h2>
        <p className="text-blue-100 text-sm mt-1">
          {isEditing
            ? 'Update your task details below'
            : 'Fill in the details to create a new task'}
        </p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        {/* Title Field */}
        <div className="space-y-2">
          <label
            htmlFor="title"
            className="block text-sm font-medium text-gray-700 flex items-center gap-2"
          >
            <FileText className="w-4 h-4" />
            Task Title
            <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            id="title"
            value={formData.title}
            onChange={(e) => updateField('title', e.target.value)}
            className={`w-full px-4 py-3 border rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
              errors.title
                ? 'border-red-300 bg-red-50'
                : 'border-gray-300 hover:border-gray-400'
            }`}
            placeholder="Enter a descriptive title for your task..."
            aria-describedby={errors.title ? 'title-error' : undefined}
          />
          {errors.title && (
            <div
              id="title-error"
              className="flex items-center gap-2 text-sm text-red-600"
              role="alert"
            >
              <AlertCircle className="w-4 h-4" />
              {errors.title}
            </div>
          )}
        </div>

        {/* Description Field */}
        <div className="space-y-2">
          <label
            htmlFor="description"
            className="block text-sm font-medium text-gray-700 flex items-center gap-2"
          >
            <FileText className="w-4 h-4" />
            Description
            <span className="text-red-500">*</span>
          </label>
          <textarea
            id="description"
            value={formData.description}
            onChange={(e) => updateField('description', e.target.value)}
            rows={4}
            className={`w-full px-4 py-3 border rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-vertical ${
              errors.description
                ? 'border-red-300 bg-red-50'
                : 'border-gray-300 hover:border-gray-400'
            }`}
            placeholder="Provide a detailed description of what needs to be done..."
            aria-describedby={errors.description ? 'description-error' : undefined}
          />
          {errors.description && (
            <div
              id="description-error"
              className="flex items-center gap-2 text-sm text-red-600"
              role="alert"
            >
              <AlertCircle className="w-4 h-4" />
              {errors.description}
            </div>
          )}
        </div>

        {/* Priority and Status Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Priority Field */}
          <div className="space-y-2">
            <label
              htmlFor="priority"
              className="block text-sm font-medium text-gray-700 flex items-center gap-2"
            >
              <Flag className="w-4 h-4" />
              Priority
            </label>
            <select
              id="priority"
              value={formData.priority}
              onChange={(e) => updateField('priority', e.target.value as Task['priority'])}
              className={`w-full px-4 py-3 border rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${getPriorityColor(
                formData.priority
              )}`}
            >
              <option value="low">Low Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="high">High Priority</option>
            </select>
          </div>

          {/* Status Field */}
          <div className="space-y-2">
            <label
              htmlFor="status"
              className="block text-sm font-medium text-gray-700 flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              Status
            </label>
            <select
              id="status"
              value={formData.status}
              onChange={(e) => updateField('status', e.target.value as Task['status'])}
              className={`w-full px-4 py-3 border rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${getStatusColor(
                formData.status
              )}`}
            >
              <option value="todo">To Do</option>
              <option value="in-progress">In Progress</option>
              <option value="completed">Completed</option>
            </select>
          </div>
        </div>

        {/* Due Date Field */}
        <div className="space-y-2">
          <label
            htmlFor="dueDate"
            className="block text-sm font-medium text-gray-700 flex items-center gap-2"
          >
            <Calendar className="w-4 h-4" />
            Due Date
            <span className="text-gray-500 text-xs">(optional)</span>
          </label>
          <input
            type="date"
            id="dueDate"
            value={formData.dueDate}
            onChange={(e) => updateField('dueDate', e.target.value)}
            className={`w-full px-4 py-3 border rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
              errors.dueDate
                ? 'border-red-300 bg-red-50'
                : 'border-gray-300 hover:border-gray-400'
            }`}
            aria-describedby={errors.dueDate ? 'dueDate-error' : undefined}
          />
          {errors.dueDate && (
            <div
              id="dueDate-error"
              className="flex items-center gap-2 text-sm text-red-600"
              role="alert"
            >
              <AlertCircle className="w-4 h-4" />
              {errors.dueDate}
            </div>
          )}
        </div>

        {/* Tags Field */}
        <div className="space-y-2">
          <label
            htmlFor="tagInput"
            className="block text-sm font-medium text-gray-700 flex items-center gap-2"
          >
            <Tag className="w-4 h-4" />
            Tags
            <span className="text-gray-500 text-xs">(press Enter to add)</span>
          </label>
          <div className="space-y-3">
            <input
              type="text"
              id="tagInput"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyPress={handleTagKeyPress}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent hover:border-gray-400"
              placeholder="Add tags to categorize your task..."
            />
            
            {/* Tag Display */}
            {formData.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full border border-blue-200"
                  >
                    <Tag className="w-3 h-3" />
                    {tag}
                    <button
                      type="button"
                      onClick={() => removeTag(tag)}
                      className="ml-1 hover:bg-blue-200 rounded-full p-0.5 transition-colors duration-200"
                      aria-label={`Remove ${tag} tag`}
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Form Actions */}
        <div className="flex flex-col sm:flex-row gap-3 pt-6 border-t border-gray-200">
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium transition-all duration-200 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                {isEditing ? 'Updating...' : 'Creating...'}
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                {isEditing ? 'Update Task' : 'Create Task'}
              </>
            )}
          </button>
          
          <button
            type="button"
            onClick={resetForm}
            disabled={isSubmitting}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg font-medium transition-all duration-200 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <RotateCcw className="w-4 h-4" />
            Reset
          </button>
        </div>
      </form>
    </div>
  );
};

export default TaskForm;