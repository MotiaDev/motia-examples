import React, { useState } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Search, Filter, Settings, Plus } from 'lucide-react';
import { KanbanColumn } from './KanbanColumn';
import type { Column, Task } from '../types/kanban';

interface KanbanBoardProps {
  columns: Column[];
  onMoveTask?: (taskId: string, sourceColumnId: string, targetColumnId: string, targetIndex: number) => void;
  onTaskClick?: (task: Task) => void;
  onAddTask?: (columnId: string) => void;
  onAddColumn?: () => void;
  onColumnMenuClick?: (columnId: string) => void;
  searchQuery?: string;
  onSearchChange?: (query: string) => void;
  className?: string;
}

/**
 * Main Kanban board component
 */
export const KanbanBoard: React.FC<KanbanBoardProps> = ({
  columns,
  onMoveTask,
  onTaskClick,
  onAddTask,
  onAddColumn,
  onColumnMenuClick,
  searchQuery = '',
  onSearchChange,
}) => {
  const [filterOpen, setFilterOpen] = useState(false);

  // Filter columns based on search query
  const filteredColumns = searchQuery.trim() 
    ? columns.map(column => ({
        ...column,
        tasks: column.tasks.filter(task =>
          task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          task.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          task.tags?.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
        ),
      }))
    : columns;

  // Calculate board statistics
  const totalTasks = columns.reduce((sum, column) => sum + column.tasks.length, 0);
  const completedTasks = columns
    .find(col => col.title.toLowerCase().includes('done') || col.title.toLowerCase().includes('complete'))
    ?.tasks.length || 0;

  return (
    <DndProvider backend={HTML5Backend}>
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        backgroundColor: '#f3f4f6'
      }}>
        {/* Board Header */}
        <div style={{
          backgroundColor: 'white',
          borderBottom: '1px solid #e5e7eb',
          padding: '16px 24px'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between'
          }}>
            {/* Board Title and Stats */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <h1 style={{ fontSize: '24px', fontWeight: 700, color: '#111827', margin: 0 }}>
                Task Board
              </h1>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px', fontSize: '14px', color: '#6b7280' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div style={{ width: '8px', height: '8px', backgroundColor: '#3b82f6', borderRadius: '50%' }}></div>
                  {totalTasks} Total Tasks
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div style={{ width: '8px', height: '8px', backgroundColor: '#22c55e', borderRadius: '50%' }}></div>
                  {completedTasks} Completed
                </span>
              </div>
            </div>

            {/* Board Actions */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              {/* Search */}
              <div style={{ position: 'relative' }}>
                <Search style={{
                  position: 'absolute',
                  left: '12px',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  width: '16px',
                  height: '16px',
                  color: '#9ca3af'
                }} />
                <input
                  type="text"
                  placeholder="Search tasks..."
                  value={searchQuery}
                  onChange={(e) => onSearchChange?.(e.target.value)}
                  style={{
                    paddingLeft: '40px',
                    paddingRight: '16px',
                    paddingTop: '8px',
                    paddingBottom: '8px',
                    border: '1px solid #d1d5db',
                    borderRadius: '8px',
                    fontSize: '14px',
                    width: '256px',
                    backgroundColor: '#f9fafb',
                    outline: 'none'
                  }}
                  aria-label="Search tasks"
                />
              </div>

              {/* Filter Button */}
              <button
                onClick={() => setFilterOpen(!filterOpen)}
                style={{
                  padding: '8px',
                  borderRadius: '8px',
                  border: `1px solid ${filterOpen ? '#3b82f6' : '#d1d5db'}`,
                  backgroundColor: filterOpen ? '#eff6ff' : 'white',
                  color: filterOpen ? '#3b82f6' : '#6b7280',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.2s ease'
                }}
                title="Filter tasks"
                aria-label="Filter tasks"
              >
                <Filter style={{ width: '16px', height: '16px' }} />
              </button>

              {/* Settings Button */}
              <button
                style={{
                  padding: '8px',
                  borderRadius: '8px',
                  border: '1px solid #d1d5db',
                  backgroundColor: 'white',
                  color: '#6b7280',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'all 0.2s ease'
                }}
                title="Board settings"
                aria-label="Board settings"
              >
                <Settings style={{ width: '16px', height: '16px' }} />
              </button>

              {/* Add Column Button */}
              <button
                onClick={onAddColumn}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '8px 16px',
                  backgroundColor: '#3b82f6',
                  color: 'white',
                  borderRadius: '8px',
                  border: 'none',
                  fontWeight: 500,
                  fontSize: '14px',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s ease'
                }}
                aria-label="Add new column"
              >
                <Plus style={{ width: '16px', height: '16px' }} />
                Add Column
              </button>
            </div>
          </div>

          {/* Filter Panel */}
          {filterOpen && (
            <div style={{
              marginTop: '16px',
              padding: '16px',
              backgroundColor: '#f9fafb',
              borderRadius: '8px',
              border: '1px solid #e5e7eb'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                <span style={{ fontSize: '14px', fontWeight: 500, color: '#374151' }}>Filter by:</span>
                <select style={{
                  padding: '6px 12px',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '14px',
                  backgroundColor: 'white',
                  cursor: 'pointer'
                }}>
                  <option>All Priorities</option>
                  <option>High Priority</option>
                  <option>Medium Priority</option>
                  <option>Low Priority</option>
                </select>
                <select style={{
                  padding: '6px 12px',
                  border: '1px solid #d1d5db',
                  borderRadius: '6px',
                  fontSize: '14px',
                  backgroundColor: 'white',
                  cursor: 'pointer'
                }}>
                  <option>All Assignees</option>
                  <option>Unassigned</option>
                </select>
                <button style={{
                  padding: '6px 12px',
                  fontSize: '14px',
                  color: '#3b82f6',
                  backgroundColor: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  fontWeight: 500
                }}>
                  Clear Filters
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Board Content */}
        <div style={{ flex: 1, overflow: 'hidden' }}>
          <div style={{ height: '100%', overflowX: 'auto', overflowY: 'hidden' }}>
            <div style={{
              display: 'flex',
              gap: '24px',
              padding: '24px',
              height: '100%',
              minWidth: 'max-content'
            }}>
              {filteredColumns.map((column) => (
                <KanbanColumn
                  key={column.id}
                  column={column}
                  onTaskClick={onTaskClick}
                  onAddTask={onAddTask}
                  onColumnMenuClick={onColumnMenuClick}
                  onMoveTask={onMoveTask}
                />
              ))}

              {/* Add Column Placeholder */}
              <div style={{ flexShrink: 0 }}>
                <button
                  onClick={onAddColumn}
                  style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '320px',
                    height: '128px',
                    border: '2px dashed #d1d5db',
                    borderRadius: '12px',
                    backgroundColor: 'transparent',
                    color: '#9ca3af',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease'
                  }}
                  aria-label="Add new column"
                >
                  <Plus style={{ width: '32px', height: '32px', marginBottom: '8px' }} />
                  <span style={{ fontWeight: 500 }}>Add Column</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Board Footer */}
        <div style={{
          backgroundColor: 'white',
          borderTop: '1px solid #e5e7eb',
          padding: '12px 24px'
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            fontSize: '14px',
            color: '#6b7280'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
              <span>Last updated: {new Date().toLocaleTimeString()}</span>
              <span>•</span>
              <span>{filteredColumns.length} columns</span>
            </div>
            <div>
              <span>Drag and drop to reorganize tasks</span>
            </div>
          </div>
        </div>
      </div>
    </DndProvider>
  );
};

export default KanbanBoard;
