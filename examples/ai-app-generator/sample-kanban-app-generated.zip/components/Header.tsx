import React, { useState } from 'react';
import { Bell, Search, Settings, User, Menu, X, CheckSquare } from 'lucide-react';

/**
 * Header component for Task Manager Pro application
 * Provides navigation, search, notifications, and user menu
 */
const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  /**
   * Toggle mobile menu visibility
   */
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  /**
   * Toggle user dropdown menu
   */
  const toggleUserMenu = () => {
    setIsUserMenuOpen(!isUserMenuOpen);
  };

  /**
   * Toggle notifications dropdown
   */
  const toggleNotifications = () => {
    setIsNotificationsOpen(!isNotificationsOpen);
  };

  /**
   * Close all dropdowns when clicking outside
   */
  const closeAllDropdowns = () => {
    setIsUserMenuOpen(false);
    setIsNotificationsOpen(false);
  };

  return (
    <header className="bg-white border-b border-e5e7eb shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Brand */}
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <div className="bg-3b82f6 p-2 rounded-lg">
                <CheckSquare className="h-6 w-6 text-white" />
              </div>
              <h1 className="ml-3 text-xl font-bold text-black font-inter">
                Task Manager Pro
              </h1>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a
              href="#dashboard"
              className="text-black hover:text-3b82f6 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200"
              aria-label="Dashboard"
            >
              Dashboard
            </a>
            <a
              href="#tasks"
              className="text-black hover:text-3b82f6 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200"
              aria-label="Tasks"
            >
              Tasks
            </a>
            <a
              href="#projects"
              className="text-black hover:text-3b82f6 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200"
              aria-label="Projects"
            >
              Projects
            </a>
            <a
              href="#calendar"
              className="text-black hover:text-3b82f6 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200"
              aria-label="Calendar"
            >
              Calendar
            </a>
          </nav>

          {/* Search Bar */}
          <div className="hidden md:flex flex-1 max-w-md mx-8">
            <div className="relative w-full">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-e5e7eb" aria-hidden="true" />
              </div>
              <input
                type="text"
                placeholder="Search tasks, projects..."
                className="block w-full pl-10 pr-3 py-2 border border-e5e7eb rounded-lg bg-white text-black placeholder-e5e7eb focus:outline-none focus:ring-2 focus:ring-3b82f6 focus:border-transparent transition-all duration-200"
                aria-label="Search tasks and projects"
              />
            </div>
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            {/* Notifications */}
            <div className="relative">
              <button
                onClick={toggleNotifications}
                className="p-2 text-black hover:text-3b82f6 hover:bg-e5e7eb rounded-lg transition-all duration-200 relative"
                aria-label="Notifications"
                aria-expanded={isNotificationsOpen}
                aria-haspopup="true"
              >
                <Bell className="h-5 w-5" />
                <span className="absolute -top-1 -right-1 h-4 w-4 bg-3b82f6 text-white text-xs rounded-full flex items-center justify-center">
                  3
                </span>
              </button>

              {/* Notifications Dropdown */}
              {isNotificationsOpen && (
                <>
                  <div
                    className="fixed inset-0 z-10"
                    onClick={closeAllDropdowns}
                    aria-hidden="true"
                  />
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-e5e7eb z-20">
                    <div className="p-4 border-b border-e5e7eb">
                      <h3 className="text-lg font-semibold text-black">Notifications</h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      <div className="p-4 hover:bg-e5e7eb transition-colors duration-200">
                        <p className="text-sm font-medium text-black">Task deadline approaching</p>
                        <p className="text-xs text-e5e7eb mt-1">Website redesign due in 2 hours</p>
                      </div>
                      <div className="p-4 hover:bg-e5e7eb transition-colors duration-200">
                        <p className="text-sm font-medium text-black">New project assigned</p>
                        <p className="text-xs text-e5e7eb mt-1">Mobile app development project</p>
                      </div>
                      <div className="p-4 hover:bg-e5e7eb transition-colors duration-200">
                        <p className="text-sm font-medium text-black">Team meeting reminder</p>
                        <p className="text-xs text-e5e7eb mt-1">Daily standup in 30 minutes</p>
                      </div>
                    </div>
                    <div className="p-4 border-t border-e5e7eb">
                      <button className="text-3b82f6 text-sm font-medium hover:text-60a5fa transition-colors duration-200">
                        View all notifications
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Settings */}
            <button
              className="p-2 text-black hover:text-3b82f6 hover:bg-e5e7eb rounded-lg transition-all duration-200"
              aria-label="Settings"
            >
              <Settings className="h-5 w-5" />
            </button>

            {/* User Menu */}
            <div className="relative">
              <button
                onClick={toggleUserMenu}
                className="flex items-center space-x-2 p-2 text-black hover:text-3b82f6 hover:bg-e5e7eb rounded-lg transition-all duration-200"
                aria-label="User menu"
                aria-expanded={isUserMenuOpen}
                aria-haspopup="true"
              >
                <div className="h-8 w-8 bg-3b82f6 rounded-full flex items-center justify-center">
                  <User className="h-4 w-4 text-white" />
                </div>
                <span className="hidden md:block text-sm font-medium">John Doe</span>
              </button>

              {/* User Dropdown */}
              {isUserMenuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-10"
                    onClick={closeAllDropdowns}
                    aria-hidden="true"
                  />
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-e5e7eb z-20">
                    <div className="p-4 border-b border-e5e7eb">
                      <p className="text-sm font-medium text-black">John Doe</p>
                      <p className="text-xs text-e5e7eb">john.doe@company.com</p>
                    </div>
                    <div className="py-2">
                      <a
                        href="#profile"
                        className="block px-4 py-2 text-sm text-black hover:bg-e5e7eb transition-colors duration-200"
                      >
                        Profile
                      </a>
                      <a
                        href="#preferences"
                        className="block px-4 py-2 text-sm text-black hover:bg-e5e7eb transition-colors duration-200"
                      >
                        Preferences
                      </a>
                      <a
                        href="#help"
                        className="block px-4 py-2 text-sm text-black hover:bg-e5e7eb transition-colors duration-200"
                      >
                        Help & Support
                      </a>
                    </div>
                    <div className="border-t border-e5e7eb py-2">
                      <button className="block w-full text-left px-4 py-2 text-sm text-black hover:bg-e5e7eb transition-colors duration-200">
                        Sign out
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={toggleMenu}
              className="md:hidden p-2 text-black hover:text-3b82f6 hover:bg-e5e7eb rounded-lg transition-all duration-200"
              aria-label="Toggle mobile menu"
              aria-expanded={isMenuOpen}
            >
              {isMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-e5e7eb">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {/* Mobile Search */}
              <div className="px-3 py-2">
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-4 w-4 text-e5e7eb" aria-hidden="true" />
                  </div>
                  <input
                    type="text"
                    placeholder="Search..."
                    className="block w-full pl-10 pr-3 py-2 border border-e5e7eb rounded-lg bg-white text-black placeholder-e5e7eb focus:outline-none focus:ring-2 focus:ring-3b82f6 focus:border-transparent"
                    aria-label="Search tasks and projects"
                  />
                </div>
              </div>

              {/* Mobile Navigation Links */}
              <a
                href="#dashboard"
                className="block px-3 py-2 text-black hover:text-3b82f6 hover:bg-e5e7eb rounded-md text-base font-medium transition-colors duration-200"
              >
                Dashboard
              </a>
              <a
                href="#tasks"
                className="block px-3 py-2 text-black hover:text-3b82f6 hover:bg-e5e7eb rounded-md text-base font-medium transition-colors duration-200"
              >
                Tasks
              </a>
              <a
                href="#projects"
                className="block px-3 py-2 text-black hover:text-3b82f6 hover:bg-e5e7eb rounded-md text-base font-medium transition-colors duration-200"
              >
                Projects
              </a>
              <a
                href="#calendar"
                className="block px-3 py-2 text-black hover:text-3b82f6 hover:bg-e5e7eb rounded-md text-base font-medium transition-colors duration-200"
              >
                Calendar
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;