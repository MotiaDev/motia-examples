import React from 'react';
import { useDrag } from 'react-dnd';
import { Calendar, User, Tag, AlertCircle } from 'lucide-react';
import type { Task, DragItem } from '../types/kanban';

interface TaskCardProps {
  task: Task;
  columnId: string;
  index: number;
  onClick?: () => void;
}

/**
 * Individual task card component with drag and drop support
 */
export const TaskCard: React.FC<TaskCardProps> = ({
  task,
  columnId,
  index,
  onClick,
}) => {
  const [{ isDragging }, drag] = useDrag<DragItem, void, { isDragging: boolean }>({
    type: 'task',
    item: { id: task.id, type: 'task', columnId, index },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });

  const getPriorityStyles = (priority: Task['priority']) => {
    switch (priority) {
      case 'high':
        return { bg: '#fee2e2', text: '#991b1b', border: '#fecaca' };
      case 'medium':
        return { bg: '#fef3c7', text: '#92400e', border: '#fde68a' };
      case 'low':
        return { bg: '#dcfce7', text: '#166534', border: '#bbf7d0' };
      default:
        return { bg: '#f3f4f6', text: '#374151', border: '#e5e7eb' };
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  };

  const priorityStyles = getPriorityStyles(task.priority);

  return (
    <div
      ref={drag}
      onClick={onClick}
      style={{
        backgroundColor: 'white',
        borderRadius: '8px',
        border: '1px solid #e5e7eb',
        padding: '16px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        cursor: 'pointer',
        opacity: isDragging ? 0.5 : 1,
        transform: isDragging ? 'rotate(2deg) scale(1.02)' : 'none',
        transition: 'all 0.2s ease',
      }}
      role="button"
      tabIndex={0}
      aria-label={`Task: ${task.title}`}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          onClick?.();
        }
      }}
    >
      {/* Task Title */}
      <h3 style={{ 
        fontWeight: 500, 
        color: '#111827', 
        fontSize: '14px',
        marginBottom: '8px',
        lineHeight: '1.4'
      }}>
        {task.title}
      </h3>

      {/* Task Description */}
      {task.description && (
        <p style={{ 
          color: '#6b7280', 
          fontSize: '12px',
          marginBottom: '12px',
          lineHeight: '1.4',
          display: '-webkit-box',
          WebkitLineClamp: 2,
          WebkitBoxOrient: 'vertical',
          overflow: 'hidden'
        }}>
          {task.description}
        </p>
      )}

      {/* Tags */}
      {task.tags && task.tags.length > 0 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px', marginBottom: '12px' }}>
          {task.tags.slice(0, 3).map((tag, idx) => (
            <span
              key={idx}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '4px',
                padding: '4px 8px',
                backgroundColor: '#eff6ff',
                color: '#1d4ed8',
                fontSize: '11px',
                borderRadius: '4px',
                border: '1px solid #bfdbfe'
              }}
            >
              <Tag style={{ width: '10px', height: '10px' }} />
              {tag}
            </span>
          ))}
          {task.tags.length > 3 && (
            <span style={{
              padding: '4px 8px',
              backgroundColor: '#f3f4f6',
              color: '#6b7280',
              fontSize: '11px',
              borderRadius: '4px'
            }}>
              +{task.tags.length - 3}
            </span>
          )}
        </div>
      )}

      {/* Task Footer */}
      <div style={{ 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'space-between',
        paddingTop: '8px',
        borderTop: '1px solid #f3f4f6'
      }}>
        {/* Priority Badge */}
        <div style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '4px',
          padding: '4px 8px',
          backgroundColor: priorityStyles.bg,
          color: priorityStyles.text,
          fontSize: '11px',
          fontWeight: 500,
          borderRadius: '4px',
          border: `1px solid ${priorityStyles.border}`,
          textTransform: 'capitalize'
        }}>
          <AlertCircle style={{ width: '12px', height: '12px' }} />
          {task.priority}
        </div>

        {/* Task Meta */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#9ca3af' }}>
          {/* Assignee */}
          {task.assignee && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }} title={`Assigned to ${task.assignee}`}>
              <User style={{ width: '12px', height: '12px' }} />
              <span style={{ fontSize: '11px', maxWidth: '60px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {task.assignee.split(' ')[0]}
              </span>
            </div>
          )}

          {/* Due Date */}
          {task.dueDate && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }} title={`Due ${formatDate(task.dueDate)}`}>
              <Calendar style={{ width: '12px', height: '12px' }} />
              <span style={{ fontSize: '11px' }}>{formatDate(task.dueDate)}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
