import { create } from 'zustand';
import { persist } from 'zustand/middleware';

/**
 * Sidebar store state interface
 */
interface SidebarState {
  /** Whether the sidebar is collapsed */
  isCollapsed: boolean;
  /** Currently active navigation item */
  activeItem: string;
  /** Toggle sidebar collapsed state */
  toggleCollapsed: () => void;
  /** Set the active navigation item */
  setActiveItem: (item: string) => void;
  /** Set collapsed state directly */
  setCollapsed: (collapsed: boolean) => void;
}

/**
 * Zustand store for managing sidebar state
 * Persists state to localStorage for better UX
 */
export const useSidebarStore = create<SidebarState>()(
  persist(
    (set) => ({
      isCollapsed: false,
      activeItem: 'dashboard',
      
      toggleCollapsed: () =>
        set((state) => ({ isCollapsed: !state.isCollapsed })),
      
      setActiveItem: (item: string) =>
        set({ activeItem: item }),
      
      setCollapsed: (collapsed: boolean) =>
        set({ isCollapsed: collapsed }),
    }),
    {
      name: 'sidebar-storage',
      partialize: (state) => ({
        isCollapsed: state.isCollapsed,
        activeItem: state.activeItem,
      }),
    }
  )
);